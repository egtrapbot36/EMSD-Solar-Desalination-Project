SmartMeasuringCup
=================

Use a liquid level sensor to build a measuring cup you can read with an Arduino.  See the guide on the Adafruit learning system: https://learn.adafruit.com/smart-measuring-cup/overview
